import asyncio
import websockets
from websockets.exceptions import ConnectionClosedOK


class DanmakuServer:
    """
    Receive danmakus from clients, reply them correctly
    """

    def __init__(self):
        self.num = 1
        self.connections = {}

    async def reply(self, websocket):
        while True:
            try:
                recv_str = await websocket.recv()
                if websocket not in self.connections:
                    self.connections[websocket] = str(self.num) # 将所有的客户端放入字典中
                    self.num = self.num + 1
                for w in self.connections: # 广播给所有的客户端
                    await w.send("person"+self.connections[websocket] + ':' + recv_str)
            except ConnectionClosedOK: # 如果客户端关闭了界面，就把他移出集合
                if websocket in self.connections:
                    self.connections.pop(websocket)
                    continue


if __name__ == "__main__":
    server = DanmakuServer()
    asyncio.get_event_loop().run_until_complete(
        websockets.serve(server.reply, 'localhost', 8765))
    asyncio.get_event_loop().run_forever()
