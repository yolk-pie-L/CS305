# coding=utf-8
import random
import time

from flask import Flask, request, jsonify, make_response

app = Flask(__name__)


danmus = {} #字典，danmus[timestamp]=danmutext
id_time = {} #字典，id_time[id]=timestamp
danmu_id = {} #弹幕是哪个id发的, danmu_id[danmu_text] = id

# 当POST的时候，将弹幕的时间和弹幕的内容放进字典danmus中，在GET的时候返回给前端做页面更新
@app.route("/", methods=["POST"])
def post_danmu():
    datas = request.form.to_dict()
    danmu_id[datas["danmu_text"]] = datas["id"] #记录弹幕是哪个id发的
    danmus[time.time()] = datas["danmu_text"]

    response = make_response()
    response.headers['Access-Control-Allow-Origin'] = '*' # 解决跨域问题
    return response


@app.route("/", methods=["GET"])
def get_danmu():
    current = time.time()
    result = [] # 发给前端的需要更新的弹幕
    id = int(request.args.get("id")) # 通过id得到是哪个进程
    if id == 0: # 如果该进程没有被标志过
        id = random.randint(1, 50000) #产生一个0到50000的数用来标识不同进程
        while id in id_time.keys():
            id = random.randint(1, 50000)
        id_time[id] = current
    for k in list(danmus.keys()):
        if current - k > 10:
            del danmus[k] # 当弹幕超时，则把弹幕删掉
        elif k > id_time[id]: # 如果弹幕的发送时间比上次前端来请求的时间晚的话，就把弹幕放进result里面
            result.append(danmus[k] + ": " + danmu_id[danmus[k]])
    result.append(id) #如果进程没有被标志过，则设置一个1到50000的随机数来标志它，如果它已经被标志过，则保持不变
    id_time[id] = current #更新该进程访问过的时间
    response = make_response(jsonify(result)) #将结果发回去
    response.headers['Access-Control-Allow-Origin'] = '*' # 解决跨域问题
    return response


if __name__ == "__main__":
    app.config["JSON_AS_ASCII"] = False
    app.run(host="127.0.0.1", port=8765)
