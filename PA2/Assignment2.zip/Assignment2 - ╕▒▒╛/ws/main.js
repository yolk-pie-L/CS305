const timers = [];
const jqueryDom = createDanmaku('hihihi'); // test danmaku, delete it as you like
addInterval(jqueryDom);// test danmaku, delete it as you like

const ws = new WebSocket('ws://localhost:8765');// 创建websocket

// 当弹幕有变更的时候，后端向前端发送更新的弹幕
ws.addEventListener("message", function(event) {
    var data = event.data;
    var arr = data.split(':');
    const jqueryDom = createDanmaku(arr[1])
    addInterval(jqueryDom)
    var Words = document.getElementById("words");
    var str = "";
    str = '<div class="talk"><span>' + data +'</span></div>';
    Words.innerHTML = Words.innerHTML + str; // 添加到聊天框中
});

// 如果按下Send按钮，就向服务器发送弹幕里的内容
$(".send").on("click", function () {
    var danmu_text = document.getElementById("danmakutext").value;
    ws.send(danmu_text);
});

// create a Dom object corresponding to a danmaku
function createDanmaku(text) {
    const jqueryDom = $("<div class='bullet'>" + text + "</div>");
    const fontColor = "rgb(255,255,255)";
    const fontSize = "20px";
    let top = Math.floor(Math.random() * 400) + "px";
    const left = $(".screen_container").width() + "px";
    jqueryDom.css({
        "position": 'absolute',
        "color": fontColor,
        "font-size": fontSize,
        "left": left,
        "top": top,
    });
    $(".screen_container").append(jqueryDom);
    return jqueryDom;
}

// add timer task to let the danmaku fly from right to left
function addInterval(jqueryDom) {
    let left = jqueryDom.offset().left - $(".screen_container").offset().left;
    const timer = setInterval(function () {
        left--;
        jqueryDom.css("left", left + "px");
        if (jqueryDom.offset().left + jqueryDom.width() < $(".screen_container").offset().left) {
            jqueryDom.remove();
            clearInterval(timer);
        }
    }, 5); // set delay as 5ms,which means the danmaku changes its position every 5ms
    timers.push(timer);
}